<template>
  <div>
    <slot></slot>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        title: "我是title"
      }
    }
  }
</script>

<style scoped>

</style>