<template>
  <div>
    <h2>{{message}}</h2>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        message: "Hello Category"
      }
    }
  }
</script>

<style scoped>

</style>