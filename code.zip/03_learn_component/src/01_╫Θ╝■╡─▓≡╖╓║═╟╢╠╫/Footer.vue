<template>
  <div class="footer">
    <h2>Footer</h2>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>