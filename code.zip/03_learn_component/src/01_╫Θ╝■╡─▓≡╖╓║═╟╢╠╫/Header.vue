<template>
  <div class="header">
    <h2>Header</h2>
    <h2>NavBar</h2>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>