/**
 * Scan the page for root level Vue instances.
 */
export declare function scan(): any[];
