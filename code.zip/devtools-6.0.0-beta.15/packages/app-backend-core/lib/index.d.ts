import { Bridge } from '@vue-devtools/shared-utils';
export declare function initBackend(bridge: Bridge): Promise<void>;
