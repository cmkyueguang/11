import { DevtoolsHook } from '@vue-devtools/app-backend-api';
export declare const hook: DevtoolsHook;
