export declare function installToast(): void;
