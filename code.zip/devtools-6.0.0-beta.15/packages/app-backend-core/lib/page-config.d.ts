export declare function initOnPageConfig(): void;
