import { TimelineLayerOptions } from '@vue/devtools-api';
export declare const builtinLayers: TimelineLayerOptions[];
