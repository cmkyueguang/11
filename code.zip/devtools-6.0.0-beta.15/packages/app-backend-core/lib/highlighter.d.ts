import { BackendContext } from '@vue-devtools/app-backend-api';
export declare function highlight(instance: any, ctx: BackendContext): Promise<void>;
export declare function unHighlight(): Promise<void>;
