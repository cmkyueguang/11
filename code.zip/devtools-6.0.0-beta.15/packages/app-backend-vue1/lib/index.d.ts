import { DevtoolsBackend } from '@vue-devtools/app-backend-api';
export declare const backend: DevtoolsBackend;
