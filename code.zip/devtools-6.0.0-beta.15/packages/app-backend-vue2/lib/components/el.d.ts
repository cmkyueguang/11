/**
 * Get the client rect for an instance.
 */
export declare function getInstanceOrVnodeRect(instance: any): any;
export declare function findRelatedComponent(el: any): any;
