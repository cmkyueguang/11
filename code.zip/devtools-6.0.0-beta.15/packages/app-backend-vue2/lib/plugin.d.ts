import { DevtoolsApi } from '@vue-devtools/app-backend-api';
import { App } from '@vue/devtools-api';
export declare function setupPlugin(api: DevtoolsApi, app: App): void;
