import { BackendContext } from '@vue-devtools/app-backend-api';
export declare function wrapVueForEvents(app: any, Vue: any, ctx: BackendContext): void;
