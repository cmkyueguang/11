export declare type ID = number | string;
export interface WithId {
    id: ID;
}
