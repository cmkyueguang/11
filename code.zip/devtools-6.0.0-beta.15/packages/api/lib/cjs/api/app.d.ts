export declare type App = any;
