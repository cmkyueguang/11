export declare const HOOK_SETUP = "devtools-plugin:setup";
