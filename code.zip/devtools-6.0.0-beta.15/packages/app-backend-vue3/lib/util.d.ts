export declare function flatten(items: any): any;
export declare function basename(filename: any, ext: any): string;
export declare function returnError(cb: () => any): any;
