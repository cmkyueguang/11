import { sum } from "./js/math";
const { priceFormat } = require("./js/format");

console.log(sum(20, 30));
console.log(priceFormat());
