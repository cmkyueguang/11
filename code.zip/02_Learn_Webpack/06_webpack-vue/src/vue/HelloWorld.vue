<template>
  <h2>Hello World组件</h2>
</template>

<script>
  export default {
    data() {
      return {
        
      }
    }
  }
</script>

<style>
</style>