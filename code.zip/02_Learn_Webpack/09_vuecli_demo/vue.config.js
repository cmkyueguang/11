module.exports = {
  configureWebpack: {

  }
}