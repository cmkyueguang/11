const message = "Hello World";
const names = ["abc", "cba", "nba"];

names.forEach(item => console.log(item));
