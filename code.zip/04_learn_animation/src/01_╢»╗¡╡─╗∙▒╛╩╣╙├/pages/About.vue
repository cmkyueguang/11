<template>
  <div>
    <h2>关于组件</h2>
    <p>哈哈哈哈啊哈哈哈</p>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>