<template>
  <div>
    <h2>home组件</h2>
    <p>呵呵呵呵呵呵</p>
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style scoped>

</style>