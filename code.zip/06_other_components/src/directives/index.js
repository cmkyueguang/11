import registerFormatTime from './format-time';

export default function registerDirectives(app) {
  registerFormatTime(app);
}