export default function(app) {
  console.log(app);
}