export default {
  install(app) {
    app.config.globalProperties.$name = "coderwhy"
  }
}