import { createStore } from 'vuex'

const store = createStore({
  state: () => {
    return {
      name: 'coderwhy'
    }
  },
  mutations: {},
  getters: {},
  actions: {}
})

export default store
